# dashboard/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.vehicles_by_make_view, name='vehicles_by_make'),
    # Add more paths for other visualizations
]
