import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from django.http import HttpResponse
from io import BytesIO
from django.conf import settings
from django.shortcuts import render
import base64

def plot_to_image(fig):
    """Converts a Matplotlib figure to a PNG image and returns it."""
    buffer = BytesIO()
    fig.savefig(buffer, format='png')
    buffer.seek(0)
    return buffer

def vehicles_by_make_view(request):
    # Load data from a CSV file
    filepath = settings.CSV_FILE_PATH
    df = pd.read_csv(filepath)

    # Create a plot for number of vehicles by make
    plt.figure(figsize=(12, 6))
    sns.countplot(y='Make', data=df, order=df['Make'].value_counts().index)
    plt.title('Number of Vehicles by Make')
    plt.xlabel('Count')
    plt.ylabel('Make')
    make_plot_image = plot_to_image(plt.gcf())
    plt.close()

    # Create a scatter plot of Electric Range vs Base MSRP
    plt.figure(figsize=(10, 6))
    plt.scatter(df['Electric Range'], df['Base MSRP'])
    plt.title('Scatter Plot of Electric Range vs Base MSRP')
    plt.xlabel('Electric Range')
    plt.ylabel('Base MSRP')
    range_plot_image = plot_to_image(plt.gcf())
    plt.close()

    plt.figure(figsize=(8,6))
    plt.hist(df['Electric Range'].value_counts(),bins=30)
    plt.title("Electric vehicle Population Cities")
    plt.xlabel("cities")
    plt.ylabel("frequency")
    hist_plot_image=plot_to_image(plt.gcf())
    plt.close()

    plt.figure(figsize=(10, 6))
    sns.boxplot(x='Make', y='Base MSRP', data=df)
    plt.title('Box Plot of Base MSRP by Make')
    plt.xlabel('Make')
    plt.ylabel('Base MSRP')
    plt.xticks(rotation=90)
    box_plot_image=plot_to_image(plt.gcf())

    # Convert images to base64
    make_plot_image_base64 = base64.b64encode(make_plot_image.getvalue()).decode('utf-8')
    range_plot_image_base64 = base64.b64encode(range_plot_image.getvalue()).decode('utf-8')
    hist_plot_image_base64= base64.b64encode(hist_plot_image.getvalue()).decode('utf-8')
    box_plot_image_base64= base64.b64encode(box_plot_image.getvalue()).decode('utf-8')

    # Pass images to template
    context = {
        'make_plot_image': make_plot_image_base64,
        'range_plot_image': range_plot_image_base64,
        'hist_plot_image': hist_plot_image_base64,
        'box_plot_image': box_plot_image_base64,
    }

    return render(request, 'index.html', context)
